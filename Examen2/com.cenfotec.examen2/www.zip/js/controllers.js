angular.module('examen.controllers', [])

.controller('ExamenController', function($scope) {
  
  $scope.images = [
    {
      name: 'Photo01',
      date: '12/15/2015',
      src: '../img/photos.png', 
    },
  ];

    $scope.getPhoto = function(){
    navigator.camera.getPicture(function(uri){
      $scope.lastPhoto = uri;
    }, function(error){
      console.error(error);
    },
    {
      quality: 75,
      targetWidth: 300,
      targetHeight: 300,
      allowEdit: true
    }
    );
  };
 })   


